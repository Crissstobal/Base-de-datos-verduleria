from typing import List, Tuple
import sqlite3 as sql

class Proveedor:
    def __init__(self, id_proveedor: int, nombre: str, telefono: str, direccion: str):
        self.id_proveedor = id_proveedor
        self.nombre = nombre
        self.telefono = telefono
        self.direccion = direccion

    def guardar(self, conn: sql.Connection):
        """Guarda el proveedor en la base de datos."""
        cursor = conn.cursor()
        cursor.execute('INSERT INTO proveedores (id_proveedor, nombre, telefono, direccion) VALUES (?, ?, ?, ?)',
                       (self.id_proveedor, self.nombre, self.telefono, self.direccion))
        conn.commit()
        print(f"Proveedor '{self.nombre}' ingresado con éxito.")

    @staticmethod
    def obtener_proveedores(conn: sql.Connection) -> List[Tuple[int, str, str, str]]:
        """Obtiene todos los proveedores de la base de datos."""
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM proveedores')
        return cursor.fetchall()

    @staticmethod
    def eliminar_proveedor(conn: sql.Connection, id_proveedor: int):
        """Elimina un proveedor de la base de datos."""
        cursor = conn.cursor()
        cursor.execute('DELETE FROM proveedores WHERE id_proveedor = ?', (id_proveedor,))
        conn.commit()
        print(f"Proveedor con ID {id_proveedor} eliminado con éxito.")
