from gestor_verduleria import Verduleria

def menu():
    verduleria = Verduleria()

    while True:
        print("\nMenú de Verdulería")
        print("1. Ingresar Producto")
        print("2. Mostrar Inventario")
        print("3. Vender Producto")
        print("4. Buscar Producto")
        print("5. Ingresar Proveedor")
        print("6. Mostrar Proveedores")
        print("7. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            id_producto = int(input("ID del producto: "))
            nombre = input("Nombre del producto: ")
            cantidad = int(input("Cantidad: "))
            precio = float(input("Precio: "))
            verduleria.ingresar_producto(id_producto, nombre, cantidad, precio)

        elif opcion == '2':
            verduleria.mostrar_inventario()

        elif opcion == '3':
            id_producto = int(input("ID del producto a vender: "))
            cantidad_vendida = int(input("Cantidad a vender: "))
            verduleria.vender_producto(id_producto, cantidad_vendida)

        elif opcion == '4':
            nombre_parcial = input("Nombre del producto a buscar: ")
            verduleria.buscar_producto(nombre_parcial)

        elif opcion == '5':
            id_proveedor = int(input("ID del proveedor: "))
            nombre = input("Nombre del proveedor: ")
            telefono = input("Teléfono del proveedor: ")
            direccion = input("Dirección del proveedor: ")
            verduleria.ingresar_proveedor(id_proveedor, nombre, telefono, direccion)

        elif opcion == '6':
            verduleria.mostrar_proveedores()

        elif opcion == '7':
            print("Saliendo...")
            break

        else:
            print("Opción no válida, intente de nuevo.")

if __name__ == "__main__":
    menu()
