from typing import List, Tuple
import sqlite3 as sql

class Inventario:
    def __init__(self, id_producto: int, cantidad: int, precio: float):
        self.id_producto = id_producto
        self.cantidad = cantidad
        self.precio = precio

    def actualizar(self, conn: sql.Connection):
        """Actualiza el inventario en la base de datos."""
        cursor = conn.cursor()
        cursor.execute('UPDATE inventario SET cantidad = ?, precio = ? WHERE id_producto = ?',
                       (self.cantidad, self.precio, self.id_producto))
        conn.commit()

    @staticmethod
    def obtener_inventario(conn: sql.Connection) -> List[Tuple[int, int, float]]:
        """Obtiene todo el inventario de la base de datos."""
        cursor = conn.cursor()
        cursor.execute('SELECT id_producto, cantidad, precio FROM inventario')
        return cursor.fetchall()

    @staticmethod
    def obtener_producto_por_id(conn: sql.Connection, id_producto: int) -> Tuple[int, int, float]:
        """Obtiene un producto específico del inventario por su ID."""
        cursor = conn.cursor()
        cursor.execute('SELECT id_producto, cantidad, precio FROM inventario WHERE id_producto = ?', (id_producto,))
        return cursor.fetchone()

    @staticmethod
    def eliminar_producto(conn: sql.Connection, id_producto: int):
        """Elimina un producto del inventario."""
        cursor = conn.cursor()
        cursor.execute('DELETE FROM inventario WHERE id_producto = ?', (id_producto,))
        conn.commit()

