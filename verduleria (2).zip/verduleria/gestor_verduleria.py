from database import Database
from producto import Producto
from proveedor import Proveedor
from inventario import Inventario
from typing import List, Tuple  # Asegúrate de que estas importaciones estén presentes

class Verduleria:
    def __init__(self):
        self.ganancias = 0.0
        self.db = Database()
        self.db.crear_tablas()

    def cargar_datos(self) -> Tuple[List[Tuple[int, str]], List[Tuple[int, int, float]], List[Tuple[int, str, str, str]]]:
        """Carga los datos de productos, inventarios y proveedores desde la base de datos."""
        productos = Producto.obtener_productos(self.db.conn)
        inventario = Inventario.obtener_inventario(self.db.conn)
        proveedores = Proveedor.obtener_proveedores(self.db.conn)
        return productos, inventario, proveedores

    def mostrar_inventario(self):
        """Muestra el inventario."""
        inventario = Inventario.obtener_inventario(self.db.conn)
        for inv in inventario:
            print(f"ID Producto: {inv[0]}, Cantidad: {inv[1]}, Precio: {inv[2]}")

    def vender_producto(self, id_producto: int, cantidad_vendida: int):
        """Vende un producto y actualiza el inventario."""
        producto = Inventario.obtener_producto_por_id(self.db.conn, id_producto)
        if producto and producto[1] >= cantidad_vendida:
            nuevo_inventario = producto[1] - cantidad_vendida
            cursor = self.db.conn.cursor()
            cursor.execute('UPDATE inventario SET cantidad = ? WHERE id_producto = ?', (nuevo_inventario, id_producto))
            self.db.conn.commit()
            self.ganancias += cantidad_vendida * producto[2]
            print(f"Producto vendido. Ganancia: {cantidad_vendida * producto[2]}")
        else:
            print("Stock insuficiente o producto no encontrado")

    def ingresar_producto(self, id_producto: int, nombre: str, cantidad: int, precio: float):
        """Ingresa un nuevo producto e inventario a la base de datos."""
        producto = Producto(id_producto, nombre)
        producto.guardar(self.db.conn)
        inventario = Inventario(producto.id_producto, cantidad, precio)
        inventario.actualizar(self.db.conn)

    def eliminar_producto(self, id_producto: int):
        """Elimina un producto del inventario."""
        Inventario.eliminar_producto(self.db.conn, id_producto)

    def buscar_producto(self, nombre_parcial: str):
        """Busca productos por nombre parcial."""
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM inventario WHERE nombre LIKE ?", ('%' + nombre_parcial + '%',))
        productos = cursor.fetchall()
        if productos:
            for prod in productos:
                print(f"ID Producto: {prod[0]}, Nombre: {prod[1]}, Cantidad: {prod[2]}, Precio: {prod[3]}")
        else:
            print("No se encontraron productos.")

    def leer_filas_ordenadas(self, campo: str):
        """Lee los productos del inventario ordenados por un campo."""
        cursor = self.db.conn.cursor()
        cursor.execute(f"SELECT * FROM inventario ORDER BY {campo} DESC")
        productos = cursor.fetchall()
        for prod in productos:
            print(f"ID Producto: {prod[0]}, Nombre: {prod[1]}, Cantidad: {prod[2]}, Precio: {prod[3]}")

    # Métodos para gestionar proveedores
    def ingresar_proveedor(self, id_proveedor: int, nombre: str, telefono: str, direccion: str):
        """Ingresa un nuevo proveedor en la base de datos."""
        proveedor = Proveedor(id_proveedor, nombre, telefono, direccion)
        proveedor.guardar(self.db.conn)
        print(f"Proveedor '{nombre}' ingresado con éxito.")

    def mostrar_proveedores(self):
        """Muestra la lista de proveedores."""
        proveedores = Proveedor.obtener_proveedores(self.db.conn)
        for prov in proveedores:
            print(f"ID Proveedor: {prov[0]}, Nombre: {prov[1]}, Teléfono: {prov[2]}, Dirección: {prov[3]}")

    def eliminar_proveedor(self, id_proveedor: int):
        """Elimina un proveedor de la base de datos."""
        Proveedor.eliminar_proveedor(self.db.conn, id_proveedor)
        print(f"Proveedor con ID {id_proveedor} eliminado con éxito.")
