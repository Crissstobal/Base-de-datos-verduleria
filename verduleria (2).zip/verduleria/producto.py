from typing import List, Tuple
import sqlite3 as sql

class Producto:
    def __init__(self, id_producto: int, nombre: str):
        self.id_producto = id_producto
        self.nombre = nombre

    def guardar(self, conn: sql.Connection):
        """Guarda el producto en la base de datos."""
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO inventario (id_producto, nombre, cantidad, precio) VALUES (?, ?, ?, ?)',
                           (self.id_producto, self.nombre, 0, 0.0))  # Cantidad y precio inicializados en 0
            conn.commit()
            print(f"Producto '{self.nombre}' ingresado con éxito.")
        except sql.IntegrityError:
            print(f"Error: El producto con ID {self.id_producto} ya existe.")

    @staticmethod
    def obtener_productos(conn: sql.Connection) -> List[Tuple[int, str]]:
        """Obtiene todos los productos de la base de datos."""
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM inventario')
        return cursor.fetchall()
